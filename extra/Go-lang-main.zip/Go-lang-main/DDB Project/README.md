![Screenshot from 2023-06-10 16-48-50](https://github.com/hebamuh68/Go-lang/assets/69214737/45d4e3ff-6ca7-4b42-aa5c-de982a349d75)

![Screenshot from 2023-06-10 16-48-58](https://github.com/hebamuh68/Go-lang/assets/69214737/cfa75277-e6df-48e4-b281-bd4db8e1f3da)
