package sumNums

func SumNum(a, b int) int {
	return a+b
}