package main

import (
	"fmt"

	"news.com/events/packages"
)

func main(){
	fmt.Println(sumNums.SumNum(1, 3))
}