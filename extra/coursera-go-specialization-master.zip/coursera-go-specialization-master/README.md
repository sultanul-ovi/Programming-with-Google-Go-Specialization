# coursera-go-specialization
My solutions for Programming with Google Go Specialization assignments.

Pass -m for gcflags to see where did compiler allocate memory for variables - on stack or heap:
```
>go build -o demo.exe -gcflags -m
```
