This is my code for the exercises and assignments of the following 3 Golang Programming Courses:

1. Getting Started with Go
The basics of Go, Topics include data types, protocols, formats, and writing code that incorporates RFCs and JSON. 

2. Functions, Methods, and Interfaces in Go
About functions, methods, and interfaces. Topics include the implementation of functions, function types, object-orientation in Go, methods, and class instantiation.

3. Concurrency in Go
How to implement concurrent programming in Go. Explore the roles of channels and goroutines in implementing concurrency. Topics include writing goroutines and implementing channels for communications between goroutines.
