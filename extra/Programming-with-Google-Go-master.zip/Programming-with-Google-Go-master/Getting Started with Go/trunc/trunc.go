package main

import "fmt"

func main() {
	var x int
	fmt.Println("Enter a Float.")
	fmt.Scan(&x)
	fmt.Println(int(x))
}
