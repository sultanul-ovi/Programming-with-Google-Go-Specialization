At this point, we’re ready to move into more complex data types, including arrays, slices, maps, and structs. As in the previous module, you’ll have a chance to practice writing code that makes use of these data types.
# Learning Objectives
- Describe arrays, slices, maps, and structs. Explain how they are used in Go programming.
- Write a Go program employing a loop structure that fills a slice with an arbitrary number of integers.
