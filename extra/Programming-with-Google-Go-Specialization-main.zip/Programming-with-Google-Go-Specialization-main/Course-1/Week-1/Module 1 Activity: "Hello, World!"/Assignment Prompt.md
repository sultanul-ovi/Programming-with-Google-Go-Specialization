The goal of this initial assignment is to ensure that you have set up golang properly, and that you are ready to proceed through the rest of this course.

# Prompt
Download and install the Go tools on your machine. Write a Go program to print “Hello, world!” on the screen. Compile and run the program.

Submit a screenshot of your cmd window showing you compiling and executing your code. The string “Hello, world!” should appear on the screen when you execute the code.
