This first module gets you started with Go. You'll learn about the advantages of using Go and begin exploring the language's features. Midway through the module, you’ll take a break from "theory" and install the Go programming environment on your computer. At the end of the module, you'll write a simple program that displays “Hello, World” on your screen.
# Learning Objectives
- Describe the basic features of a compiled, object-oriented programming language.
- Download and install the Go development environment on your computer.
- Write and implement a Go program that displays "Hello, World!" on your screen.
