This second module continues to explore the use of functions in Go. You’ll continue learning about the capabilities and features of functions, and write a routine that solves a practical physics problem.
# Learning Objectives
- Identify advanced types, properties, and uses of functions.
- Identify the output that would result from running a given code block containing functions.
- Develop a routine containing functions in Go that solves a practical physics problem.
