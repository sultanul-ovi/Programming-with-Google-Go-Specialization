The goal of this activity is to define Moore's law and describe the physical limitations in devices that have stopped it from continuing to be true.

# PROMPT
**Define Moore’s law** and explain why it has now stopped being true. Be sure to describe all of the physical limitations that have prevented Moore’s law from continuing to be true.

**Submission**: Upload your document in either PDF or DOCX format.
