This module looks at basic concurrency concepts and race conditions in preparation for a discussion of threads coming up in the next module.
# Learning Objectives
- Identify the characteristics of processes, concurrency, and threads.
- Explain how and why race conditions can arise.
