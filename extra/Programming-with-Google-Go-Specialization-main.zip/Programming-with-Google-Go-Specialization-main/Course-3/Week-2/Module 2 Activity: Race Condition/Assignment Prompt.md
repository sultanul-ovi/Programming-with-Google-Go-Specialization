The goal of this activity is to explore race conditions by creating and running two simultaneous goroutines.

# PROMPT
Write two goroutines which have a race condition when executed concurrently. Explain what the race condition is and how it can occur.

Submission: Upload your source code for the program along with your written explanation of race conditions.
