# Control Flow

- describes the order in which statements are executed inside the program
- most basic control flow is top-down

## Control Structures

- statements which alter control flow
  - if/if-else statements
  - for loops
  - switch/case
