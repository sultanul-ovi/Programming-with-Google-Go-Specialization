package main

import "fmt"

func main(){
	fmt.Print("Hello, world!")
}
